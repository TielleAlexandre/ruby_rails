class WelcomeController < ApplicationController
  #authenticate + nome da model (user)
  before_action :authenticate_user!, except: [:index]
  def index
  end

  def home
  end
end
