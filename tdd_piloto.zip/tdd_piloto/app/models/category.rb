class Category < ApplicationRecord
end
