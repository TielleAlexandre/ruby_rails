FactoryBot.define do
  factory :product do
    description {Faker::Commerce.product_name}
    price {Faker::Commerce.price}
    # Vai usar a factory category para preencher aqui visto que é um belongs_to
    category
    #category { nil }
  end
end
