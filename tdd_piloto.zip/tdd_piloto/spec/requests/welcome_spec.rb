require 'rails_helper'
require 'devise'

RSpec.describe "Welcomes", type: :request do

  context 'As a Guest' do
    describe "GET /index" do
      #teste sem autenticação
      it "returns http success" do
        #faz a requisiçao e a resposta dela é retorna na variável response
        get "/welcome/index"
        #expect(response).to have_http_status(:success) ou
        expect(response).to have_http_status "200"
      end
    end
  end

  context 'As Logged User - not authorized' do
    describe "GET /home" do
      it 'responds a 302 response (not authorized)' do
        get "/welcome/home"
        expect(response).to have_http_status "302"
      end
    end
  context 'As Logged User - authorized' do
    before do
      @user = create(:user)
    end

    describe "GET /home" do
      it 'responds a 200 response (authorized)' do
          sign_in @user
          get "/welcome/home"
          expect(response).to have_http_status "200"
      end

      #Testando entradas da view para criação do usuário. Create não foi implementado.
      #it 'with valid attributes' do
        #attributes_for (devolve um hash com os dados do usuário criado pelo factory bot)
      # user_params = attributes_for(:user)
      # p user_params
      #  sign_in @user
      # após a execução do post, verifica-se se foi criado mais um elemento na modelo user
      #  expect{
      #    post :create, params: {user: user_params}
      #  }.to change(User, :count).by(1)
      # end

      it 'render a :home template' do
          sign_in @user
          get "/welcome/home"
          expect(response).to render_template("welcome/home", "layouts/application")
      end
    end
  end
end

end
