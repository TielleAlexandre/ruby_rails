Rails.application.routes.draw do
  devise_for :users
  get 'welcome/index'

  # rota protegida pelo devise conforme configuração da controller
  get 'welcome/home'
  root to: 'welcome#index'
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
