Geocoder.configure(
  lookup: :geoapify,
  api_key: "60aaf256df7f46798e08c0989e342b16"
)
