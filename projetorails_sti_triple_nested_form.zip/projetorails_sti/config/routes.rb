Rails.application.routes.draw do

  resource :get_rides do
    get '/index', to: 'get_rides#index'
    get '/create', to: 'get_rides#create'
    get '/new', to: 'get_rides#new'
    get '/show', to: 'get_rides#show'
    get '/search', to: 'get_rides#search'
    get '/autocomplete', to: 'get_rides#autocomplete'
    get '/get_rides_select', to: 'get_rides#search_get_ride_select'
  end

  resource :users do
    get '/index', to: 'users#index'
    get '/search', to: 'users#search'
    get '/autocomplete', to: 'users#autocomplete'
    get '/activate', to:'users#activate_deactivate_user'
    get '/user_select', to: 'users#search_user_select'
  end

  resource :campus_uffs do
    get '/activate', to:'campus_uffs#activate_deactivate'
  end

  get 'welcome/index'
  root to: 'users#index'
end
