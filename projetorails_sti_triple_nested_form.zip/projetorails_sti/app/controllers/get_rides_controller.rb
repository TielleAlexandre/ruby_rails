class GetRidesController < ApplicationController

  before_action :load_user_2, only: [:search_get_ride_select]

  def index


    @get_ride = GetRide.new
    @campus = CampusUff.select(:id,:nome).all

    ponto_caronas = @get_ride.ponto_caronas.build
    ponto = ponto_caronas.build_ponto


  end



  #before_action :buscar_point, only: [:create]
  def new


  end

  def show
    id_user = (User.joins(:identificacao_login).where("iduff=?",current_user.iduff)[0]).id
    @get_rides = GetRide.joins(:pontos).where("user_id=?", id_user).order(data_partida: :desc).includes(:pontos,:campus_uff)
    #render json: @get_rides
  end

  def search

  end

  def search_get_ride_select

  end


  def autocomplete
    term =params[:searchTerm]
    @pontos = Ponto.select("pontos.bairro")
                   .distinct
                   .where("pontos.bairro like ? ","%#{term}%")

    #.order(:)
    #.limit(20)
    render json: @pontos
  end
  def create
    @get_ride = GetRide.new(params_get_rides)
    @get_ride.user_id = (User.joins(:identificacao_login).where("iduff=?",current_user.iduff)[0]).id


    @get_ride.ponto_caronas.each do |ponto_carona|
      coordenadas = localizarEndereco(ponto_carona.ponto.endereco, ponto_carona.ponto.numero, ponto_carona.ponto.bairro,ponto_carona.ponto.cidade_id)
      puts "a coordenada do meu endereco é: " +"#{coordenadas}"
      ponto_carona.ponto.latitude =coordenadas[0]
      ponto_carona.ponto.longitude =coordenadas[1]

      existing_ponto = buscar_point2(ponto_carona.ponto.latitude, ponto_carona.ponto.longitude)
      puts "mostrar ponto:"+ "#{existing_ponto.inspect}"
         if existing_ponto
           ponto_carona.ponto = existing_ponto
         end
      end


    #@get_ride.pontos.build(params_pontos)
    #@get_ride.pontos.ponto_caronas.build(params_ponto_caronas)


    puts "aqui: " + "#{@get_ride.inspect}"

    # params[:get_ride][:pontos_attributes].each do |ponto|
    # p = Ponto.where('latitude=? and longitude=?', "#{ponto.latitude}","#{ponto.longitude}")[0].first_or_initialize
    # if !p.nil?
    #   ponto = p
    # end
    #end

    # @get_ride.pontos.build
    # @get_ride.pontos.ponto_caronas.build
    #puts "aqui: " + "#{@get_ride.inspect}"
    #puts "aqui está: " + "#{@ponto.inspect}"
    #if @ponto.nil?
    #  @ponto = Ponto.new(params_pontos)
    #  @ponto.cidade_id =3643
    # @pontos.cidade_id=Pub::Cidade.where('nome like ?', "%#{@pontos.cidade}%").pluck(:id)
    #end

    #@array_pontos = Ponto.new(params_pontos)
    #buscar_point

    #if @get_ride.pontos << @array_pontos
        if @get_ride.save!
        puts "cadastrei..."
          redirect_to get_rides_path
       else
          puts "não cadastrei..."
        end
     end


  private
  def params_get_rides
    #params.require(:get_ride).permit(:campus_uff_id,:partida_campi_uff,:observacao,:custo,:qtd_passageiro,:data_partida, pontos_attributes: [:endereco, :numero,:bairro,:cidade_id,:cep,:latitude,:longitude, :_destroy, ponto_caronas_attributes: [:destino_final]])
    #params.require(:get_ride).permit(:campus_uff_id,:partida_campi_uff,:observacao,:custo,:qtd_passageiro,:data_partida, pontos_attributes: [])
    params.require(:get_ride).permit(:campus_uff_id,:partida_campi_uff,:observacao,:custo,:qtd_passageiro,:data_partida, ponto_caronas_attributes: [:id, :_destroy, :destino_final, ponto_attributes: [:id, :endereco, :numero,:bairro,:cidade_id,:cep]])
  end

  #def params_pontos
    #params.require(:get_ride).permit(:pontos => [:endereco, :numero,:bairro,:cidade,:cep,:latitude,:longitude])
    #params[:get_ride][:pontos].permit(:endereco, :numero,:bairro,:cidade_id,:cep,:latitude,:longitude)
    #params.require(:get_ride).permit(pontos_attributes: [:endereco, :numero,:bairro,:cidade_id,:cep,:latitude,:longitude, ponto_caronas_attributes:[]])
  #end

   def buscar_point()
    @array_pontos = params[:get_ride][:pontos_attributes]
    @array_pontos.each do |ponto|
      p = Ponto.where('latitude=? and longitude=?', "#{ponto.latitude}","#{ponto.longitude}")[0]
      if !p.nil?
        @array_pontos = p
      end
    end
  end

  def buscar_point2(latitude, longitude)
    Ponto.where('latitude=? and longitude=?', "#{latitude}","#{longitude}")[0]
    #Ponto.find_by(latitude, longitude)
  end


  def load_user_2
    render json: msg=(GetRide.select("get_rides.data_partida","campus_uffs.nome","get_rides.partida_campi_uff", "pontos.*","get_rides.qtd_passageiro","get_rides.custo","get_rides.observacao")
                             .joins(:pontos,:campus_uff)
                             .where("pontos.bairro like ? ","%#{params[:id]}%"))
    #.select("get_rides.data_partida","campus_uff.nome","get_rides.qtd_passageiro","get_rides.custo","get_rides.observacao"))
    #.select('get_rides.data_partida','get_rides.campus_uff','get_rides.qtd_passageiro','get_rides.custo','get_rides.observacao')


    #.select("users.id","identificacoes_login.nome", "identificacoes_login.iduff", "users.admin")
    # .select("get_rides.d ata_partida","get_rides.campus_uff.nome","get_rides.qtd_passageiro","get_rides.custo","get_rides.observacao")
  end

  def localizarEndereco(endereco,numero,bairro,cidade)
    results = Geocoder.search("#{endereco}" + ", " + "#{numero}" + ", " + "#{bairro}" + ", " + "#{cidade}")
    results.first.coordinates
    #puts "a coordenada do meu endereco é: " +"#{results.first.coordinates}"
  end

  def construirEndereco(ponto)

  end
end


