class CampusUffsController < ApplicationController
  before_action :set_campus_uff, only: [:edit,:activate_deactivate]
  before_action :set_campus_uff_update, only: [:update]
  before_action :search_city, only: [:new,:edit]

  def show
    @campus_uffs=CampusUff.all.page(params[:page]).includes(:cidade)
  end

  def new
    @campus_uff=CampusUff.new
    @campus_uff.cidade = Pub::Cidade.new
  end

  def create
    if CampusUff.new(params_campus_uff).save!(validate:false)
      redirect_to campus_uffs_path, notice: "Campus salvo."
    else
      render :new
    end
  end

  def edit

  end

  def update
    if @campus_uff.update(params_campus_uff)
      redirect_to campus_uffs_path, notice: "Usuário atualizado."
    else
      render :edit
    end
  end


  # rever redirecionamento
  def activate_deactivate
     @campus_uff.ativo ? active=false : active=true
     if @campus_uff.update(ativo:active)
       redirect_to campus_uffs_path, notice: "Usuário atualizado."
     else
       render :new
     end
   end

  private

  def params_campus_uff
    params.require(:campus_uff).permit(:id,:nome,:endereco,:numero,:bairro,:cidade_id,:cep)
  end

  # não aceita include
  # format? Pq não reconece o id do campus_uff
  def set_campus_uff
     @campus_uff = CampusUff.find(params[:format])
  end

  def set_campus_uff_update
    @campus_uff = CampusUff.find(params[:campus_uff][:id])
  end

  def search_city
    @cidades= Pub::Cidade.where('estado_id in (18,13)').order(:nome).pluck(:nome,:id)
  end
end


