class UsersController < ApplicationController
  before_action :search_user_update, only: [:update,:activate_deactivate_user]
  before_action :load_user, only: [:edit, :destroy]
  before_action :load_user_2, only: [:search_user_select]
  before_action :search_logged_user



  #rever ordenação
  def show
    @users=User.all.page(params[:page])
               .order(:id)
               .includes(:identificacao_login)
  end

  def index

  end

  def new
    @user = User.new
    @user.identificacao_login= Pub::IdentificacaoLogin.new
  end

  def edit
  end

  def destroy
    if @user.destroy && load_identificacao_login(@user.identificacao_login_id).destroy
      redirect_to users_path, notice: "Usuário excluído."
    else
      render :show
    end
  end

  def create
    identificacao_login=Pub::IdentificacaoLogin.new(params_identificacao_login)
    if identificacao_login.save!(validate:false)
      @user=User.new(params_user)
      @user.identificacao_login=search_user(identificacao_login.iduff)[0]
      if @user.save!(validate:false)
        redirect_to users_path, notice: "Usuário salvo."
      else
        render :new
      end
    end
  end

  def activate_deactivate_user
    identificacao_login = load_identificacao_login(@user.identificacao_login_id)
    #false "\x00" true "\x01"
    @user

    identificacao_login.inspect
    puts identificacao_login.ativo

    if identificacao_login.ativo=="\x00"
      puts "chequei aq 1"
      valor="\x01"
      data=nil
    else
      puts "chequei aq 2"
      valor="\x00"
      data=DateTime.now.to_date
    end

    if @user.update!(:data_desativacao=>data) && identificacao_login.update_column(:ativo,valor)
      redirect_to users_path, notice: "Usuário desativado."
    else
      render :edit
    end
  end

  def update
    identificacao_login=load_identificacao_login(@user.identificacao_login_id)
    #atualização de atributos sem validação
    if @user.update(params_user) && identificacao_login.update_columns(params_identificacao_login)
         redirect_to users_path, notice: "Usuário atualizado."
    else
      render :edit
    end
  end

  def search


  end

  def search_user_select

  end

  #.where("nome LIKE ?","%#{term}%")

  def autocomplete
    term =params[:searchTerm]
    @users = User.joins(:identificacao_login)
                .select("users.id","identificacoes_login.nome")
                .where("identificacoes_login.nome like ? or identificacoes_login.iduff=?","%#{term}%","#{term}")
                 .order(:nome)
                 .limit(20)
    render json: @users
  end

  private

  def load_user
    @user = User.find(params[:format])
  end

  def load_user_2
    render json: msg=(User.joins(:identificacao_login)
                          .select("users.id","identificacoes_login.nome", "identificacoes_login.iduff", "users.admin")
                          .where("users.id=?",params[:id]))
  end


  def load_identificacao_login(id)
   Pub::IdentificacaoLogin.find(id)
  end

  def search_user(iduff)
    Pub::IdentificacaoLogin.where('iduff=?', "#{iduff}").limit(1)
  end

  def search_logged_user
    if @logged_user.nil?
      puts "passei por aq"
      @logged_user=(User.joins(:identificacao_login).where("iduff=?",current_user.iduff)[0]).admin
    end
  end


  def search_user_update
    @user = User.find(params[:user][:id])
  end

  def params_identificacao_login
    params.require(:identificacao_login).permit(:nome,:iduff).to_h
  end

  def params_user
    params.require(:user).permit(:id,:admin)
  end

  def load_users
    @users= User.joins(:identificacao_login)
                .order(:nome)
                .includes(:identificacao_login)
    end

end
