module CampusUffsHelper
end
