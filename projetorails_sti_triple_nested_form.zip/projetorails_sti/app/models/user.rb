class User < ApplicationRecord
  paginates_per 5
  belongs_to :identificacao_login, class_name: 'Pub::IdentificacaoLogin'
end
