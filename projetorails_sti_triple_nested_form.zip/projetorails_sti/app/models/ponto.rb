class Ponto < ApplicationRecord

  has_many :ponto_caronas
  has_many :get_rides, through: :ponto_caronas

  accepts_nested_attributes_for :ponto_caronas

end


#validates_uniqueness_of :latitude, :longitude
#has_and_belongs_to_many :get_rides