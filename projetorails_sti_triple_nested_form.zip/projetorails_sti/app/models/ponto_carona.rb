class PontoCarona < ApplicationRecord
  belongs_to :ponto
  belongs_to :get_ride

  accepts_nested_attributes_for :ponto, allow_destroy: true

end
