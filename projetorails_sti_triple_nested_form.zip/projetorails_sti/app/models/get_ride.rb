  class GetRide < ApplicationRecord
    belongs_to :campus_uff
    belongs_to :user

    has_many :ponto_caronas
    has_many :pontos, through: :ponto_caronas
    accepts_nested_attributes_for :ponto_caronas, allow_destroy: true
    accepts_nested_attributes_for :pontos
    # validates_associated :pontos

    #before_validation :find_foos

    #, :reject_if => :check_store
    private

    def find_foos
      self.pontos = self.pontos.map do |object|
        Ponto.where(value: object.value).first_or_initialize
      end
    end

    def check_store(ponto_attr)
      ponto = Ponto.where('latitude=? and longitude=?', "#{ponto_attr['latitude']}","#{ponto_attr['longitude']}")[0]
      if ponto.nil?
        return false
      end
      return true
    end

    def geolocalizacao

    end


  end
