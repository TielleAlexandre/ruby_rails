class CampusUff < ApplicationRecord
  paginates_per 5
  belongs_to :cidade, class_name: 'Pub::Cidade'
end
