$(document).ready(function() {
    $('#campus_partida_nao_e_uff').click(function() {
       $("#partida_campus_uff").val("false");
        var div2 = $('#campus_uff');
        var div3 =$('#label_destino');
        var div4 = $('#enderecos');

        div2.insertAfter(div4);
        div4.insertBefore(div3);

        $("#carona").css("display", "block");
    });

    $('#campus_partida_uff').click(function() {
        $("#partida_campus_uff").val("true");
        $("#carona").css("display", "block");
    });
});
