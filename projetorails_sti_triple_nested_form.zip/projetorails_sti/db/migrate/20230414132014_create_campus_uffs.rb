class CreateCampusUffs < ActiveRecord::Migration[6.1]
  def change
    create_table :campus_uffs do |t|
      t.string :nome
      t.string :endereco
      t.integer :numero
      t.string :bairro
      t.string :cep
      t.integer :cidade_id
      t.boolean :ativo

      t.timestamps
    end
  end
end
