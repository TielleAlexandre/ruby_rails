class CreateGetRides < ActiveRecord::Migration[6.1]
  def change
    create_table :get_rides do |t|
      t.references :campus_uff, null: false, foreign_key: true
      t.references :user, null: false, foreign_key: true
      t.datetime :data_partida
      t.integer :qtd_passageiro
      t.float :custo
      t.string :observacao
      t.boolean :partida_campi_uff

      t.timestamps
    end
  end
end
