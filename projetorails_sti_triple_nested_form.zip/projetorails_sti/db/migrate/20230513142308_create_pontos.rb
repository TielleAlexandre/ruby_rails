class CreatePontos < ActiveRecord::Migration[6.1]
  def change
    create_table :pontos do |t|
      t.string :endereco
      t.integer :numero
      t.string :bairro
      t.string :cep
      t.integer :cidade_id
      t.string :latitude
      t.string :longitude

      t.timestamps
    end
  end
end
