class CreatePontoCaronas < ActiveRecord::Migration[6.1]
  def change
    create_table :ponto_caronas do |t|
      t.references :ponto, null: false, foreign_key: true
      t.references :get_ride, null: false, foreign_key: true
      t.boolean :destino_final

      t.timestamps
    end
  end
end
