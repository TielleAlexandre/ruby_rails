class CreateUsers < ActiveRecord::Migration[6.1]
  def change
    create_table :users do |t|
      t.date :data_desativacao
      t.boolean :admin
      t.integer :identificacao_login_id

      t.timestamps
    end
  end
end
